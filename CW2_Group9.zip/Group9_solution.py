# This checks if the user has not successfully guessed all the letters in the secret word but still has guesses left. The partially solved word is displayed.
def is_secret_guessed(secret_word,letters_guessed):
    try:
        if "".join(letters_guessed) == secret_word:
            return True
        else:
            return False
    except TypeError:
        print("I can't determine whether you have guessed the word.")

# This updates the counter and returns the letters guessed.
def get_current_guess(secret_word,letters_guessed):
    try:
        global count
        count -= 1
        return letters_guessed
    except:
        print("Something went wrong with your guess.")
    
# This FOR statement replaces every "_" in the letters_guessed list with the user's guess if said guess is found in the secret word.
def first_game(secret_word):
    try:
        rule = True
        global count
        global letter_guessed
        letter_guessed = ""
# Because the game has not started, no letters have been guessed. Hence, the number of guesses is 11 which is stored in a variable, count.
# The following WHILE statement uses count to simulate guesses, hence the need to initialize count = 11. This begins the Hangman game.
# In order for the game to end, the variable count must equal 0.
        while count != 0:         
            letter_guessed = input("Guess a letter in the word: ")
# The variable letter_guessed simulates the user's guess by taking in a one letter input.
            if len(letter_guessed) != 1:
                rule = False
# If the user tries to enter more than one letter at a time, they will be presented with a message and asked to re-input a letter. It will not result in the user losing a guess.
            while rule == False:
                letter_guessed = input("You can only guess one letter at a time. Guess a letter in the word: ")
                if len(letter_guessed) == 1:
                    rule = True
                else:
                    rule = False
            for j in range(0,len(letters_guessed)):
                if letter_guessed == secret_word[j]:
                    letters_guessed[j] = letter_guessed
                else:
                    continue
            is_secret_guessed(secret_word,get_current_guess(letters_guessed,secret_word))
# Displays an output telling the user how many guesses they have left to decipher the secret word.
            if is_secret_guessed(secret_word,letters_guessed) == True:
                print("\nYou Win! The word was",secret_word)
# This IF statement checks if the user successfully guesses all letters in the secret word. If this happens, the game ends and the player is given the message "You Win!"
                break
            elif is_secret_guessed(secret_word,letters_guessed) == False:
                print("\nSo far, the partially solved word is:","".join(letters_guessed))
                if count == 1:
                    print("You have",str(count),"guess left to determine what my secret word is.")
# This IF statement checks if there is 1 guess left. If so, the message changes to reflect this. It does not make sense saying "1 guesses".
                else:
                    print("You have",str(count),"guesses left to determine what my secret word is.")
        if count == 0:
            print("You Lose! The word was",secret_word)
# If the player has ran out of guesses and not guessed the secret word, the game ends and the player is given the message "You Lose."           
    except NameError:
        print("Sorry, I can't find a variable")
    except:
        print("Sorry, there seems to be an issue I don't know about.")

letters_guessed = []
# The list, letters_guessed, containing the user's guesses is empty because the game has not started.
secret_word = "Corporation"
# The secret word, "Corporation", is a string assigned to a constant variable called secret_word.
# This is Player 1's secret word.
for i in range(0,len(secret_word)):
    letters_guessed.append("_")
print("The secret word has",str(len(secret_word)),"characters.")
count = 15
print("You have",str(count),"guess left to determine what my secret word is.")
letter_guessed = ""
# this FOR statement repeats adding "_" as a character to the letters_guessed list. The number of times it does so is the same number as the length of the variable secret_word.
# The variable letter_guessed is an empty string because the game has not started. In other words, the user has not made any guesses.
first_game(secret_word)

def load_words(filename):
    try:
        global words
# By declaring the variables as global, it prevents having to redefine the same variables locally.
# This function loads the words.txt file which "Player 1" uses.
        words = open(str(filename)+".txt").read().splitlines()
        print("\nThere are",str(len(words)),"random words in my library.")
# The user is informed of the number of words in the file words.txt.
# The list words is sent to 
    except:
        print("File",filename+".txt does not exist!")
        exit
        
def choose_secret_word():
    try:
        load_words("gamewords")
        global words
        global letters_guessed
        import random
        return words[random.randint(0,len(words)-1)]
# [@Anjola] This statment allows for a (randomly chosen) specific line in the text file to be read rather than the whole file.
        words.clear()
        letters_guessed.clear()
        for m in range(0,len(words[random.randint(0,len(words)-1)])):
            letters_guessed.append("_")
        print("The secret word has",str(len(words[random.randint(0,len(words)-1)])),"characters.")
    except TypeError:
        print("My word library is missing.")

# The second_game is essentially the first game, game code is identical except the word that was chosen is used.
def second_game():
    try:
        rule = True
        global count
        global letter_guessed
        print("You have",str(count),"guesses left to determine what my secret word is.")
        letter_guessed = ""
        while count != 0:         
            letter_guessed = input("Guess a letter in the word: ")
            if len(letter_guessed) != 1:
                rule = False
            while rule == False:
                letter_guessed = input("You can only guess one letter at a time. Guess a letter in the word: ")
                if len(letter_guessed) == 1:
                    rule = True
                else:
                    rule = False
            for j in range(0,len(letters_guessed)):
                if letter_guessed == secret_word[j]:
                    letters_guessed[j] = letter_guessed
                else:
                    continue
            is_secret_guessed(secret_word,get_current_guess(letters_guessed,secret_word))
            if is_secret_guessed(secret_word,letters_guessed) == True:
                print("\nYou Win! The word was",secret_word)
                with open("stats.txt", "a") as myfile:
                    myfile.write("\nwin")
                    myfile.close()
                break
            elif is_secret_guessed(secret_word,letters_guessed) == False:
                print("\nSo far, the partially solved word is:","".join(letters_guessed))
                if count == 1:
                    print("You have",str(count),"guess left to determine what my secret word is.")
                else:
                    print("You have",str(count),"guesses left to determine what my secret word is.")
        if count == 0:
            print("You Lose! The word was",secret_word)
        with open("stats.txt", "a") as myfile:
            myfile.write("\nlose")
            myfile.close()
    except NameError:
        print("Sorry, I can't find a variable")
    except:
        print("Sorry, there seems to be an issue I don't know about.")

def game_stats(num1):
    try:
        stats = open("stats.txt").read().splitlines()
        stats.rstrip()
        wins = 0
        losses = 0
        for n in range(0,num1):
            try:
                if stats[n] == "win":
                    wins += 1
                if stats[n] == "lose":
                    losses += 1
            except IndexError:
                print("Oh dear, I tried looking for a non-existent line.")
        print("\nIn",str(num1),"games, you have had",str(wins),"wins and",str(losses),"losses.")
        print("The average number of wins to losses is",str(wins/losses))
    except:
        print("I can't seem to display the game statistics.")

count = 15
secret_word = choose_secret_word()
print(secret_word)
letters_guessed.clear()
for m in range(0,len(secret_word)):
    letters_guessed.append("_")
second_game()
try:
    usr_simulations = int(input("Enter the number of simulations of hangman: "))
    game_stats(usr_simulations)
except ValueError:
    print("Enter a number!")
    exit
