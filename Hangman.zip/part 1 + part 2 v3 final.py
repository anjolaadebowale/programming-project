# This checks if the user has successfully guessed all the letters in the secret word but still has guesses left. The partially solved word is displayed.
def is_secret_guessed(secret_word,letters_guessed):
    try:
        if "".join(letters_guessed) == secret_word:
            return True
        else:
            return False
    except TypeError:
        print("I can't determine whether you have guessed the word.")

# This updates the counter and returns the letters guessed as a string.
def get_current_guess(secret_word,letters_guessed):
    try:
        global count
        count -= 1
        return "".join(letters_guessed)
    except:
        print("Something went wrong with your guess.")
    
def first_game(secret_word):
    try:
        rule = True
        global count
        global letter_guessed
        letter_guessed = ""
# [@Rrshai] Because the game has not started, no letters have been guessed.
# [@Rrshai] The following WHILE statement uses count to simulate guesses. This begins the Hangman game.
        while count != 0:
        # [@Rrshai] In order for the game to end, the variable count must equal 0.
            letter_guessed = input("Guess a letter in the word: ")
            # [@Rrshai] The variable letter_guessed simulates the user's guess by taking in a one letter input.
            if len(letter_guessed) != 1:
                rule = False
            # [@Rrshai] If the user tries to enter more than one letter at a time, they will be presented with a message and asked to re-input a letter. It will not result in the user losing a guess.
            while rule == False:
                letter_guessed = input("You can only guess one letter at a time. Guess a letter in the word: ")
                if len(letter_guessed) == 1:
                    rule = True
                else:
                    rule = False
            # [@Rrshai] Replaces every "_" in the letters_guessed list with the user's guess if said guess is found in the secret word.
            for j in range(0,len(letters_guessed)):
                if letter_guessed == secret_word[j]:
                    letters_guessed[j] = letter_guessed
                else:
                    continue
            is_secret_guessed(secret_word,get_current_guess(letters_guessed,secret_word))
            # [@Rrshai] A composite function, using the returned value of the user's current guess and the secret word, returns True if the word has been guessed or false if not.
            # [@Rrshai] Displays an output telling the user how many guesses they have left to decipher the secret word.
            if is_secret_guessed(secret_word,letters_guessed) == True:
                print("\nYou Win! The word was",secret_word)
                # [@Anjola] This IF statement checks if the user successfully guesses all letters in the secret word. If this happens, the game ends and the player is given the message "You Win!"
                break
            elif is_secret_guessed(secret_word,letters_guessed) == False:
                print("\nSo far, the partially solved word is:","".join(letters_guessed))
                if count == 1:
                    print("You have",str(count),"guess left to determine what my secret word is.")
                # [@Rrshai] This IF statement checks if there is 1 guess left. If so, the message changes to reflect this. It does not make sense saying "1 guesses".
                else:
                    print("You have",str(count),"guesses left to determine what my secret word is.")
        if count == 0:
            print("You Lose! The word was",secret_word)
# [@Rrshai] If the player has ran out of guesses and not guessed the secret word, the game ends and the player is given the message "You Lose."           
    except NameError:
        print("Sorry, I can't find a variable")
    except:
        print("Sorry, there seems to be an issue I don't know about.")

letters_guessed = []
# [@Rrshai] The list, letters_guessed, containing the user's guesses is empty because the game has not started.
secret_word = "Corporation"
# [@Rrshai] The secret word, "Corporation", is a string assigned to a constant variable called secret_word.
# [@Rrshai] This is Player 1's secret word.
# [@Rrshai] this FOR statement repeats adding "_" as a character to the letters_guessed list. The number of times it does so is the same number as the length of the variable secret_word.
for i in range(0,len(secret_word)):
    letters_guessed.append("_")
print("The secret word has",str(len(secret_word)),"characters.")
count = 15
print("You have",str(count),"guess left to determine what my secret word is.")
letter_guessed = ""
# [@Rrshai] The variable letter_guessed is an empty string because the game has not started. In other words, the user has not made any guesses.
first_game(secret_word)

#The function = load_words
def load_words():
    count = 0
    words = open("gamewords.txt", "r")
    # [@Anjola] This statment opens the text file "gamewords.txt" where are the words are stored.
    for i in words:
    # [@Anjola] The for loop is use to find the number of items in the text file, by going through each item in the text.
    # [@Anjola] The loop stops counting once the progam reaches the end of the text file.
        count = count + 1
    print("There are " + str(count) + " words")
    # [@Anjola] This statment returns the total number of words in the text file.
    words.close()
    words = open("gamewords.txt", "r")
    list_of_words = words.read()
    # [@Anjola] This statment creates a variable to store the contents of the text file.
    print(list_of_words)
    # [@Anjola] This prints the words in the list.
    words.close()

def choose_secret_word():
    words = open("gamewords.txt", "r")
    # [@Anjola] This opens the text file that contains the words
    count=0
    for i in words:
    # [@Anjola] Use the for loop to find the total number of words, to use as the range when using "randrange".
        count=count+1
    print(count)
    words.close()
    # [@Rrshai] secret_word is locally declared in this instance as one of the words will be returned anyway.
    words = open("gamewords.txt", "r")
    import random
    randomnum = random.randrange(count)
    # [@Anjola] Ensuring the random number can be matched to a word, this generates a random integer below the total number words.
    print(randomnum)
    secret_word=  words.readlines()
    # [@Anjola] This statment allows for a specific line in the text file to be read rather than the whole file
    words.close()
    return (secret_word[randomnum])
    # [@Anjola] This returns the word with the index of the random number selected. [@Rrshai] Needed to assign a secret word second time.

# [@Rrshai] The second_game is essentially the first game, game code is somewhat identical.
def second_game():
    try:
        rule = True
        global count
        global secret_word
        # [@Rrshai] All variables declared global are outside this function. This is to ensure that the count updated is recognised by all functions.
        global letter_guessed
        print("You have",str(count),"guesses left to determine what my secret word is.")
        letter_guessed = ""
        while count != 0:         
            letter_guessed = input("Guess a letter in the word: ")
            if len(letter_guessed) != 1:
                rule = False
            while rule == False:
                letter_guessed = input("You can only guess one letter at a time. Guess a letter in the word: ")
                if len(letter_guessed) == 1:
                    rule = True
                else:
                    rule = False
            for j in range(0,len(letters_guessed)):
                if letter_guessed == secret_word[j]:
                    letters_guessed[j] = letter_guessed
                else:
                    continue
            is_secret_guessed(secret_word,get_current_guess(letters_guessed,secret_word))
            if is_secret_guessed(secret_word,letters_guessed) == True:
                print("\nYou Win! The word was",secret_word)
                # [@Rrshai] If the user has won, the statistics of win/lose are updated by adding win to a new line.
                with open("stats.txt", "a") as myfile:
                    myfile.write("\nwin")
                    myfile.close()
                break
                # [@Rrshai] If the user has won, the loop is broken.
            elif is_secret_guessed(secret_word,letters_guessed) == False:
                print("\nSo far, the partially solved word is:","".join(letters_guessed))
                if count == 1:
                    print("You have",str(count),"guess left to determine what my secret word is.")
                else:
                    print("You have",str(count),"guesses left to determine what my secret word is.")
        if count == 0:
        # [@Anjola] If the user has lost, they will see this message.
            print("You Lose! The word was",secret_word)
        with open("stats.txt", "a") as myfile:
            myfile.write("\nlose")
            # [@Rrshai] If the user has lost, the statistics of win/lose are updated by adding lose to a new line.
            myfile.close()
    except NameError:
        print("Sorry, I can't find a variable")


def game_stats(num1):
    try:
        import random
        stats = open("stats.txt").read().splitlines()
        print("You have played",str(len(stats)),"games.")
        stats.rstrip()
        wins = 0
        losses = 0
        for n in range(0,num1):
            try:
                if stats[n] == "win":
                    wins += 1
                if stats[n] == "lose":
                    losses += 1
            except IndexError:
                print("Oh dear, I tried looking for a non-existent line.")
        print("\nIn the past",str(num1),"games, you have had",str(wins),"wins and",str(losses),"losses.")
        try:
            ratio = wins/losses
            print("The average number of wins to losses is",ratio)
        except ZeroDivisionError:
            raise ZeroDivisionError("You haven't lost a single game!")
    except:
        print("I can't seem to display the game statistics.")

count = 15
load_words()
secret_word=choose_secret_word()
# [@Anjola] Assignes the word selected within the function to the variable (secret_word)
letters_guessed.clear()
for m in range(0,len(secret_word)-1):
    letters_guessed.append("_")
# [@Anjola][@Rrshai] Before the second game can begin, the letters_guessed list must be cleared and replenished with the same number of "_" as the secret_word
second_game()
try:
    usr_simulations = int(input("Enter the number of simulations of hangman: "))
    game_stats(usr_simulations)
except ValueError:
    raise ValueError("You need to enter a number!")
